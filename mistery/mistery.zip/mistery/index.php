<?php

	Echo("
				<br>
				<br>
				<br>
				<br>
				<center>
				<small>
				<title>mistery - home</title>
				<br>
				<br>
				<h1>mistery</h1>
				<br>
				ready to begin your journey?
				<br>
				<form name = myWebForm action = quote.php method = post>
				<input type = submit value=yes />
				<br>
				by miles.
				</form>
				</small>
				</center>
				");

?>